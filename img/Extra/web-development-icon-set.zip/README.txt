Free Icons: Web Development Icon Set

This free icon set contains 200 icons.
These are the file formats available: EPS, PNG and SVG

SOURCE:
This package is from Six Revisions.
Web address: http://sixrevisions.com/free-icons/web-development-icon-set/

DESIGNED BY:
The contents of this package was created by Icons8.
Web address: https://icons8.com/

TERMS OF USE:
1. You can use the icons in this package as part of a project, even if said project is commercial in nature.
   Examples: Websites, ebooks, ecommerce sites, blogs, infographics, documents (PDF, Word docs), slideshow presentations and software user interfaces.
   
2. Attribution is appreciated.
   Attribution is not required, but we'd appreciated it.

ATTRIBUTION:
If you'd like to provide attribution,
please use the following HTML code:

<a href="http://sixrevisions.com/free-icons/web-development-icon-set/">Web Development Icon Set</a> designed by <a href="https://icons8.com/">Icons8</a>